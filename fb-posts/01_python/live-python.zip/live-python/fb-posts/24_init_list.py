print([None] * 10)
print([0] * 10)
print([[0]] * 10)
print((0,) * 10)
