stocks_1 = {'PLW': 480, 'CDR': 400}
stocks_2 = {'TEN': 520, 'CDR': 420}

result = {**stocks_1, **stocks_2}
print(result)
