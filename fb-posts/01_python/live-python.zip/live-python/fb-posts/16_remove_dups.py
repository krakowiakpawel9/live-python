stocks = ['TEN', 'PLW', 'CDR', 'BBT', 'CDR', 'TEN']
result = list(set(stocks))
print(result)
