import math


print(f'Pi: {math.pi}')
print(f'Pi: {math.pi:.2f}')
print(f'Pi: {math.pi:.4f}')
