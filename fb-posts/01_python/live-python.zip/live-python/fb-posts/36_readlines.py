with open('stocks.txt') as file:
    content = file.readlines()

print(content)
