from collections import Counter

answers = ['yes', 'no', 'yes', 'yes', 'no']
print(Counter(answers))
