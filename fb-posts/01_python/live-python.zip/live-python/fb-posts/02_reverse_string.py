text = 'Programming in Python'

print(f'Reversed text: {text[::-1]}')

