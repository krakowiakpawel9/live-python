result1 = []
for i in range(10):
    result1.append(i * i)

result2 = [i * i for i in range(10)]

print(result1)
print(result2)
