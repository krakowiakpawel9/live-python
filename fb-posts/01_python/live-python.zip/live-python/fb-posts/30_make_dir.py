import os


dir_name = 'sample'
if not os.path.exists(dir_name):
    os.makedirs(dir_name)
