def calculate1(a, b, c):
    return (a + b) * c


calculate2 = lambda a, b, c: (a + b) * c

print(calculate1(3, 4, 5))
print(calculate2(3, 4, 5))
