techs = ['python', 'java', 'c++', 'go', 'hadoop']

print(sorted(techs))
print(sorted(techs, key=len))
print(sorted(techs, key=len, reverse=True))
