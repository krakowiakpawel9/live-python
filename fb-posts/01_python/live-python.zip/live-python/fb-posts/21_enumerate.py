stocks = ['PLW', 'CDR', 'TEN', '11B', 'CIG']

for idx, ticker in enumerate(stocks):
    print(f'Index: {idx} Ticker: {ticker}')

print(tuple(enumerate(stocks)))
