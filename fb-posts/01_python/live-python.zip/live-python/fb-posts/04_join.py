techs = ['java', 'python', 'sql', 'c++']

print(','.join(techs))
print('#'.join(techs))
print(';'.join(techs))

