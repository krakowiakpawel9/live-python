ticker = ['CDR', 'PLW', 'TEN']
price = [400, 480, 520]

result = dict(zip(ticker, price))
print(result)
