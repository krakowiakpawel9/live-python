import os


extension = os.path.splitext('/path/to/file.txt')[1]
print(f'extention: {extension}')
