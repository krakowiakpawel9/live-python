with open('stocks.txt') as file:
    content = file.read()

print(content)
