import os


print(os.system('pwd'))
print(os.system('python --version'))
