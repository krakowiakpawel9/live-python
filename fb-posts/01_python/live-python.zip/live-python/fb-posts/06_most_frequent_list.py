numbers = [4, 5, 5, 3, 4, 5, 5]
most_frequent = max(numbers, key=numbers.count)
print(f'Most frequent: {most_frequent}')

