import whois

domain = whois.whois('https://e-smartdata.org/')
print(domain)
