def sample():
    return 'Python', 3.8


language, version = sample()

print(f'Language: {language}\nVersion: {version}')

