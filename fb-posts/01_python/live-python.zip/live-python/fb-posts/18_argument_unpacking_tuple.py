def print_args(var1, var2, var3):
    print(f'var1: {var1}\nvar2: {var2}\nvar3: {var3}')


variables = (3, 4, 5)
print_args(*variables)

