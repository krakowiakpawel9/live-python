close = 110.5

if close > 100:
    print('gt 100')
else:
    print('le 100')

print('gt 100') if close > 100 else print('lt 100')
