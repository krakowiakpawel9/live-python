a = 1
b = 3

a, b = b, a

print(f'a={a}')
print(f'b={b}')



